<?php
/*
    Información:  
    Enlace a video:    
    Finalidad ejercicio:  
    Alumno:
*/
?>
<?php
    //Aqui se definen todos los datos de acceso a la BBDD. Como lo son el usuario contraseña, host y mas...
    define('DB_HOST', 'mysql:host=localhost');
    define('DB_USUARIO', 'root');
    define('DB_CONTRA', '');
    define('DB_NOMBRE', 'dbname=dwes');
    define('DB_CHARSET', 'utf8');
?>