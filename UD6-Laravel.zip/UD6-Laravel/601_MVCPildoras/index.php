<?php
//Este archivo es el que hará referencia a la interfaz de usuario
//por tanto es el único , por ahora, que contiene HTML


?>
<head>

<link rel="stylesheet" type="text/css" href="hoja.css">
<meta charset="utf-8">
<title>Productos View</title>
</head>

<body>


    <h1>Index del MVC</h1>
    <p>Esta prática es un sistema CRUD MVC, video 82 Píldoras</p>  

<?php
    require_once("FALTA COMPLETAR: en qué archivo se deberá iniciar todo?");
?>


</body>
</html>